# Ponsonbys

# FR
- Script permettant de créer des tenues sur un mannequin est l'attribuer à un joueur, sur FiveM.
- Simple d'utilisation
- Optimisation 0.01 ms
- Lib : RageUI
- Pour tout support AigleIsBack#7053

# EN
- Script to create outfits on a mannequin is to assign it to a player, on FiveM.
- Easily utilisation
- Optimization 0.01 ms
- Lib: RageUI
- For any question AigleIsBack#7053

# Preview
- https://streamable.com/0thg49
